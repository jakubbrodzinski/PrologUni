:- consult('queens.pl').
:- use_module(library(pwp)).

ex2 :-
	pwp_files('queens_in.html','queens_out.html').